import os
import psycopg2
from flask import Flask, jsonify, request

app = Flask(__name__)


def get_db_connection():
    conn = psycopg2.connect(os.environ["DATABASE_URL"])
    return conn


def init_db():
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS items (
            id SERIAL PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            description TEXT,
            created_at TIMESTAMP DEFAULT NOW()
        )
    """)
    conn.commit()
    cur.close()
    conn.close()


@app.route("/")
def index():
    return jsonify({"message": "Python + PostgreSQL API is running!", "endpoints": [
        "GET /items",
        "POST /items",
        "GET /items/<id>",
        "DELETE /items/<id>"
    ]})


@app.route("/ping")
def ping():
    return "Dollhouse Bot is alive 💖"


@app.route("/items", methods=["GET"])
def get_items():
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT id, name, description, created_at FROM items ORDER BY created_at DESC")
    rows = cur.fetchall()
    cur.close()
    conn.close()
    items = [
        {"id": r[0], "name": r[1], "description": r[2], "created_at": r[3].isoformat()}
        for r in rows
    ]
    return jsonify(items)


@app.route("/items", methods=["POST"])
def create_item():
    data = request.get_json()
    if not data or "name" not in data:
        return jsonify({"error": "name is required"}), 400
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO items (name, description) VALUES (%s, %s) RETURNING id, name, description, created_at",
        (data["name"], data.get("description", ""))
    )
    row = cur.fetchone()
    conn.commit()
    cur.close()
    conn.close()
    return jsonify({"id": row[0], "name": row[1], "description": row[2], "created_at": row[3].isoformat()}), 201


@app.route("/items/<int:item_id>", methods=["GET"])
def get_item(item_id):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT id, name, description, created_at FROM items WHERE id = %s", (item_id,))
    row = cur.fetchone()
    cur.close()
    conn.close()
    if row is None:
        return jsonify({"error": "Item not found"}), 404
    return jsonify({"id": row[0], "name": row[1], "description": row[2], "created_at": row[3].isoformat()})


@app.route("/items/<int:item_id>", methods=["DELETE"])
def delete_item(item_id):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM items WHERE id = %s RETURNING id", (item_id,))
    row = cur.fetchone()
    conn.commit()
    cur.close()
    conn.close()
    if row is None:
        return jsonify({"error": "Item not found"}), 404
    return jsonify({"message": f"Item {item_id} deleted"})


if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=5000)
