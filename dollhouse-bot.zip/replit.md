# dollHouse Bot

A Discord bot with a PostgreSQL-backed XP system and a Flask REST API.

## Stack
- **Language:** Python
- **Framework:** Flask (API) + discord.py (Bot)
- **Database:** PostgreSQL (via psycopg2)

## Running
Both services start together via the "Project" workflow:
- **Discord Bot** — connects to Discord using `DISCORD_BOT_TOKEN`
- **Flask API** — listens on port 5000

## Bot Commands
| Command | Description |
|---------|-------------|
| `!hello` | Ping the bot |
| `!roles` | Post a reaction-role embed |
| `!verify dollhouse` | Verify yourself via keyword |
| `!sendverify` | Post a button-based verification embed |
| `!event` | Post a game night event with vote reactions & join button |
| `!signups [event name]` | Show how many people signed up for an event |
| `!xp [@user]` | Check XP for yourself or another member |
| `!lock` | Lock the current channel |
| `!unlock` | Unlock the current channel |
| `!addpremium @user` | (Admin) Grant premium to a user |
| `!embed <text>` | (Premium) Post a pink embed |

## Flask API Endpoints
| Method | Path | Description |
|--------|------|-------------|
| GET | `/` | API info |
| GET | `/items` | List all items |
| POST | `/items` | Create an item (`{"name": "...", "description": "..."}`) |
| GET | `/items/<id>` | Get a single item |
| DELETE | `/items/<id>` | Delete an item |

## Database Tables
- **items** — id, name, description, created_at
- **user_xp** — user_id, guild_id, xp, updated_at (persisted XP across restarts)

## Secrets
- `DISCORD_BOT_TOKEN` — Discord bot token (stored in Replit Secrets)
- `DATABASE_URL` — Set automatically by Replit
